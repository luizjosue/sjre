/*
 * Created on 19/09/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package br.ufal.tci.InferenceEngine;

import br.ufal.tci.exception.NotFoundException;
import br.ufal.tci.parser.Variable;
import br.ufal.tci.value.Value;

/**
 * @author knoppix
 *
 */
public interface InferenceEngineIF {
	
	public boolean proveVariable(Variable variable);
	/*
	 * buscar regras com variable na cabe�a da regra
	 *  para cada uma delas
	 * 	tentar provar (firerule)
	 *    if provou return true
	 *  fim -para
	 * return false;
	 *
	 *
	 *
	 *
	 *
	 *	 */

	
	/** 
	 * Procura uma vari�vel de acordo com o encadeamento implementado
	 * */
	public Value findValue(Variable variable) throws NotFoundException;
	//ATENCAO: pergunta ao usu�rio ou prova via encadeamento pra tr�s (proveVariable)
	
	/**
	 * 	Indica se o encadeamento � o encadeamento para tr�s
	 * */
	public boolean isBackwardChaining();
	
	/**
	 * 	Indica se o encadeamento � o encadeamento para frente
	 * */
	public boolean isFowardChaining();
}
