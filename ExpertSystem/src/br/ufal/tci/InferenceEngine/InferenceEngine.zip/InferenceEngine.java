/*
 * Created on 21/09/2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package br.ufal.tci.InferenceEngine;

import java.util.List;

import br.ufal.tci.exception.NotFoundException;
import br.ufal.tci.parser.Variable;
import br.ufal.tci.value.Value;

/**
 * @author mfp
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class InferenceEngine implements InferenceEngineIF{

	private InterpreterIF interpreter;
	private KnowledgeBaseIF knowledgebase;

	 public InferenceEngine(InterpreterIF ip,KnowledgeBaseIF klb){
	 	InterpreterIF interpreter = ip;
	 	KnowledgeBaseIF knowledgebase = klb;	 	
	 }
	
	/* (non-Javadoc)
		 * @see br.ufal.tci.InferenceEngine.InferenceEngineIF#proveVariable(br.ufal.tci.parser.Variable)
		 */ 
	public boolean proveVariable(Variable variable) {
		// TODO Auto-generated method stub
		List listRules;
		int i;
		
		listRules = interpreter.getRulesWithVariableInHead(variable);
		for(i = 0;i < listRules.size() - 1;i++){
			if (interpreter.fireRule(listRules.get(i)) == true){
				return true;
			}
		}
		
		return false;
	}

	/* (non-Javadoc)
	 * @see br.ufal.tci.InferenceEngine.InferenceEngineIF#findValue(br.ufal.tci.parser.Variable)
	 */
	public Value findValue(Variable variable) throws NotFoundException {
		// TODO Auto-generated method stub
		/*
		 O procedimento para se buscar uma variável é o seguinte:
		 
		  1 - Busca-se, a variável primeiro na base de conhecimento
		  2 - Ocorre uma tentativa de prova da variável 
		 * */
		 try{
		 	/*Passo 1*/
			return this.knowledgebase.lookup(variable);
		 }catch(NotFoundException nfe){
		 	/*Passo 2*/
		 	/*Agora deverá verificar se é possivel  provar a variável ou não*/
		 	if (this.proveVariable(variable) == false){
		 		/*levanta a excecao NotFoundException*/
		 		NotFoundException notFound = new NotFoundException("nao provada");
		 		throw notFound;
		 		
		 		/*Dúvida ?????????*/
		 	}
		 	
		 	
		 }
		return variable.getValue();	
		
		
		
	}

	/* (non-Javadoc)
	 * @see br.ufal.tci.InferenceEngine.InferenceEngineIF#isBackwardChaining()
	 */
	public boolean isBackwardChaining() {
		// TODO Auto-generated method stub
		return true;
	}

	/* (non-Javadoc)
	 * @see br.ufal.tci.InferenceEngine.InferenceEngineIF#isFowardChaining()
	 */
	public boolean isFowardChaining() {
		// TODO Auto-generated method stub
		return false;
	}

}
